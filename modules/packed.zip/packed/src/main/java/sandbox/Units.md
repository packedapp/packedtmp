Assembly
Application
  * Mangler launcher [Har vi generisk eller definere all AppInterfaces deres egen]
  * Mangler customizer [Eller kun wirelets?]
  * Mangler Resultat
  
Container
Bean
Service
Operation
Binding
Extension
Lifetime
Context