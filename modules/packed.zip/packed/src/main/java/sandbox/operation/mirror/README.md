----- Binding Enums

BindingTarget  -> Parameter, TypeParamer, Field, MethodHandleParameter
ResolutionState