Okay Ideen er at vi har en eller flere Guest Application|Container|Bean

Saa har vi en Host som kan launche this componenter
Hver host har en GuestAdaptorBean