Okay nye Ideer

Har forenede Application, Container, Bean component hosting

Har clerified Ideen mellem GuestAdaptor or Host
  
Man skal have hosts beans. Fordi man skal have configureret hvad man skal have injected