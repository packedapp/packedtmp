Application
Assembly
Container
Bean
Operation


//// ContainerSet vs ContainerTree???
Domain 
Namespace

Tree Pros
  Has a root where the thing can belong
  
  
  