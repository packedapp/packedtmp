package app.packed.extension;

import static java.util.Objects.requireNonNull;

import java.lang.annotation.Annotation;
import java.lang.invoke.MethodHandle;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Map;
import java.util.function.Consumer;

import app.packed.application.ApplicationMirror;
import app.packed.application.DeploymentMirror;
import app.packed.assembly.Assembly;
import app.packed.assembly.AssemblyMirror;
import app.packed.assembly.AssemblyPropagator;
import app.packed.bean.BeanClassMutator;
import app.packed.bean.BeanConfiguration;
import app.packed.bean.BeanInstallationException;
import app.packed.bean.BeanKind;
import app.packed.bean.BeanMirror;
import app.packed.bean.ComputedConstant;
import app.packed.bean.Inject;
import app.packed.bean.ManagedBeanRequiredException;
import app.packed.bean.SyntheticBean;
import app.packed.build.BuildException;
import app.packed.build.action.BuildActionable;
import app.packed.build.hook.BuildHook;
import app.packed.container.ContainerConfiguration;
import app.packed.container.ContainerLocal;
import app.packed.container.ContainerMirror;
import app.packed.container.Wirelet;
import app.packed.extension.BeanElement.BeanField;
import app.packed.extension.BeanElement.BeanMethod;
import app.packed.lifetime.Main;
import app.packed.lifetime.OnInitialize;
import app.packed.lifetime.OnStart;
import app.packed.lifetime.OnStop;
import app.packed.operation.Op;
import app.packed.operation.Op1;
import app.packed.operation.OperationMirror;
import app.packed.service.Export;
import app.packed.service.Provide;
import app.packed.service.ServiceContract;
import app.packed.service.ServiceLocator;
import app.packed.service.ServiceNamespaceConfiguration;
import app.packed.service.ServiceOutgoingTransformer;
import app.packed.service.ServiceableBeanConfiguration;
import app.packed.util.Key;
import app.packed.util.Variable;
import internal.app.packed.bean.BeanLifecycleOrder;
import internal.app.packed.bean.BeanSetup;
import internal.app.packed.bean.PackedBeanInstaller;
import internal.app.packed.bean.PackedBindableWrappedVariable;
import internal.app.packed.binding.BindingResolution.FromOperationResult;
import internal.app.packed.container.NonRootContainerBuilder;
import internal.app.packed.entrypoint.OldEntryPointSetup;
import internal.app.packed.entrypoint.OldEntryPointSetup.MainThreadOfControl;
import internal.app.packed.lifetime.runtime.ApplicationLaunchContext;
import internal.app.packed.operation.OperationSetup;
import internal.app.packed.service.PackedServiceLocator;
import sandbox.extension.bean.BeanHandle;
import sandbox.extension.bean.BeanTemplate;
import sandbox.extension.container.ContainerHandle;
import sandbox.extension.container.ContainerTemplate;
import sandbox.extension.container.guest.GuestIntoAdaptor;
import sandbox.extension.operation.OperationHandle;
import sandbox.extension.operation.OperationTemplate;
import sandbox.lifetime.external.LifecycleController;

/**
 * An extension that defines the foundational APIs for managing beans, services, containers and applications.
 * <p>
 * Every container automatically uses this extension. And every extension automatically has a direct dependency on this
 * extension.
 * <p>
 * All methods on this class deals with beans Table area [bean,container,service] prefix desciption
 * <p>
 * This extension does not define an {@link ExtensionExtension extension mirror}. Instead all relevant methods are
 * placed directly on {@link app.packed.bean.BeanMirror}, {@link app.packed.container.ContainerMirror} and
 * {@link app.packed.application.ApplicationMirror}.
 *
 * @see app.packed.container.BaseAssembly#base()
 * @see BaseWirelets
 */

// Bean
//// install

// Container
//// link

// Service
//// export
//// require
//// provide
//// transform/rewrite??? depends on 1 or two interfaces

public class BaseExtension extends FrameworkExtension<BaseExtension> {

    // We use an initial value for now, because we share FromLinks and the boolean fields
    // But right now we only have a single field
    static final ContainerLocal<FromLinks> FROM_LINKS = ContainerLocal.of(FromLinks::new);

    // Codegen vars that we need to resolve
    final ArrayList<BindableVariable> varsToResolve = new ArrayList<>();

    /** All your base are belong to us. */
    BaseExtension() {}

//    Map<Key<?>, Supplier<?>> codegens = new HashMap<>();

//    <K> void addCodeGenerated(Key<K> key, Supplier<? extends K> supplier) {
    // We need per extension...
//        if (codegens.putIfAbsent(key, supplier) != null) {
//            throw new IllegalStateException("A supplier has previously been provided for key [key = " + key + "]");
//        }
//    }

    // One of 3 models...
    // Fails on other exports
    // Ignores other exports
    // interacts with other exports in some way
    /**
     * Exports all container services and any services that have been explicitly anchored via of anchoring methods.
     * <p>
     *
     * <ul>
     * <li><b>Service already exported.</b> The service that have already been exported (under any key) are always
     * ignored.</li>
     * <li><b>Key already exported.</b>A service has already been exported under the specified key.
     * <li><b>Are requirements.</b> Services that come from parent containers are always ignored.</li>
     * <li><b>Not part of service contract.</b> If a service contract has set. Only services for whose key is part of the
     * contract is exported.</li>
     * </ul>
     * <p>
     * This method can be invoked more than once. But use cases for this are limited.
     */
    // Altsaa tror mere vi er ude efter noget a.la. exported.services = internal.services
    // Saa maske smide ISE hvis der allerede er exporteret services. Det betyder naesten ogsaa
    // at @Export ikke er supporteret
    // ect have exportAll(boolean ignoreExplicitExports) (Otherwise fails)

    // All provided services are automatically exported
    public void exportAll() {
        // Tror vi aendre den til streng service solve...
        // Og saa tager vi bare alle services() og exportere

        // Add exportAll(Predicate); //Maybe some exportAll(Consumer<ExportedConfg>)
        // exportAllAs(Function<?, Key>

        // Export all entries except foo which should be export as Boo
        // exportAll(Predicate) <- takes key or service configuration???

        // export all _services_.. Also those that are already exported as something else???
        // I should think not... Det er er en service vel... SelectedAll.keys().export()...
        checkIsConfigurable();

        extension.container.sm.exportAll = true;
    }

    // Har man brug for andet end class transformer? Er der nogle generalle bean properties??? IDK
    <T> ServiceableBeanConfiguration<T> transformingInstall(Class<T> implementation, Consumer<? super BeanClassMutator> transformation) {
        throw new UnsupportedOperationException();

    }

    /**
     * Installs a bean of the specified type. A single instance of the specified class will be instantiated when the
     * container is initialized.
     *
     * @param implementation
     *            the type of bean to install
     * @return the configuration of the bean
     * @see BaseAssembly#install(Class)
     */
    @BuildActionable("bean.install")
    public <T> ServiceableBeanConfiguration<T> install(Class<T> implementation) {
        BeanHandle<ServiceableBeanConfiguration<T>> h = install0(BeanKind.CONTAINER.template()).install(implementation, ServiceableBeanConfiguration::new);
        return h.configuration();
    }

    /**
     * Installs a component that will use the specified {@link Op} to instantiate the component instance.
     *
     * @param op
     *            the factory to install
     * @return the configuration of the bean
     * @see CommonContainerAssembly#install(Op)
     */
    public <T> ServiceableBeanConfiguration<T> install(Op<T> op) {
        BeanHandle<ServiceableBeanConfiguration<T>> h = install0(BeanKind.CONTAINER.template()).install(op, ServiceableBeanConfiguration::new);
        return h.configuration();
    }

    private PackedBeanInstaller install0(BeanTemplate template) {
        return new PackedBeanInstaller(extension, extension.container.assembly, template);
    }

    /**
     * Install the specified component instance.
     * <p>
     * If this install operation is the first install operation of the container. The component will be installed as the
     * root component of the container. All subsequent install operations on this container will have have component as its
     * parent.
     *
     * @param instance
     *            the component instance to install
     * @return this configuration
     */
    public <T> ServiceableBeanConfiguration<T> installInstance(T instance) {
        BeanHandle<ServiceableBeanConfiguration<T>> h = install0(BeanKind.CONTAINER.template()).installInstance(instance, ServiceableBeanConfiguration::new);
        return h.configuration();
    }

    public <T> ServiceableBeanConfiguration<T> install(SyntheticBean<T> synthetic) {
        throw new UnsupportedOperationException();
    }

    public <T> ServiceableBeanConfiguration<T> installLazy(SyntheticBean<T> synthetic) {
        throw new UnsupportedOperationException();
    }

    public <T> ServiceableBeanConfiguration<T> installPrototype(SyntheticBean<T> synthetic) {
        // fail for instance
        throw new UnsupportedOperationException();
    }

    public <T> ServiceableBeanConfiguration<T> installStatic(SyntheticBean<T> synthetic) {
        throw new UnsupportedOperationException();
    }

    public <T> ServiceableBeanConfiguration<T> installLazy(Class<T> implementation) {
        BeanHandle<ServiceableBeanConfiguration<T>> handle = install0(BeanKind.LAZY.template()).install(implementation, ServiceableBeanConfiguration::new);
        return handle.configuration();
    }

    public <T> ServiceableBeanConfiguration<T> installLazy(Op<T> op) {
        BeanHandle<ServiceableBeanConfiguration<T>> h = install0(BeanKind.LAZY.template()).install(op, ServiceableBeanConfiguration::new);
        return h.configuration();
    }

    public <T> ServiceableBeanConfiguration<T> installPrototype(Class<T> implementation) {
        BeanHandle<ServiceableBeanConfiguration<T>> handle = install0(BeanKind.UNMANAGED.template()).install(implementation, ServiceableBeanConfiguration::new);
        return handle.configuration();
    }

    public <T> ServiceableBeanConfiguration<T> installPrototype(Op<T> op) {
        BeanHandle<ServiceableBeanConfiguration<T>> h = install0(BeanKind.UNMANAGED.template()).install(op, ServiceableBeanConfiguration::new);
        return h.configuration();
    }

    /**
     * Installs a new {@link BeanKind#STATIC static} bean.
     *
     * @param implementation
     *            the static bean class
     * @return a configuration for the bean
     *
     * @see BeanKind#STATIC
     * @see BeanSourceKind#CLASS
     */
    public BeanConfiguration installStatic(Class<?> implementation) {
        BeanHandle<BeanConfiguration> handle = install0(BeanKind.STATIC.template()).install(implementation, BeanConfiguration::new);
        return handle.configuration();
    }

    /**
     * Installs an exported service locator.
     *
     * @see BaseExtensionPoint#EXPORTED_SERVICE_LOCATOR
     */
    void lifetimeExportServiceLocator() {
        // Create a new bean that holds the ServiceLocator to export
        // will fail if installed multiple times

        BeanHandle<ServiceableBeanConfiguration<PackedServiceLocator>> ha = newBeanBuilderSelf(BeanKind.CONTAINER.template())
                .install(PackedServiceLocator.class, ServiceableBeanConfiguration::new);
        ha.configuration().exportAs(ServiceLocator.class);

        // PackedServiceLocator needs a Map<Key, MethodHandle> which is created in the code generation phase
        BeanSetup.crack(ha).addCodeGenerated(new Key<Map<Key<?>, MethodHandle>>() {}, () -> extension.container.sm.exportedServices());

        // Alternative, If we do not use it for anything else
        newBeanBuilderSelf(BeanKind.CONTAINER.template()).installIfAbsent(PackedServiceLocator.class, BeanConfiguration.class, BeanConfiguration::new, bh -> {
            bh.exportAs(ServiceLocator.class);
            BeanSetup.crack(bh).addCodeGenerated(new Key<Map<Key<?>, MethodHandle>>() {}, () -> extension.container.sm.exportedServices());
        });
    }

    /**
     * Creates a new child container by linking the specified assembly.
     *
     * @param assembly
     *            the assembly to link
     * @param wirelets
     *            optional wirelets
     */
    // Why not on ContainerConfiguration. Think because I wanted to keep it clean
    public void link(Assembly assembly, Wirelet... wirelets) {
        link0().build(assembly, ContainerConfiguration::new, wirelets);
    }

    public void linkTransformed(Assembly assembly, BuildHook... transformers) {
        throw new UnsupportedOperationException();
    }

    public void linkTransformed(Assembly assembly, AssemblyPropagator ap, BuildHook... transformers) {
        throw new UnsupportedOperationException();
    }

    public void linkTransformed(Assembly assembly, BuildHook[] transformers, Wirelet... wirelets) {
        throw new UnsupportedOperationException();
    }

    public void linkTransformed(Assembly assembly, AssemblyPropagator ap, BuildHook[] transformers, Wirelet... wirelets) {
        throw new UnsupportedOperationException();
    }

    /**
     * Creates a new container that strongly linked to the lifetime of this container.
     *
     * @param wirelets
     *            optional wirelets
     * @return configuration for the new container
     */
    // addContainer???
    public ContainerConfiguration link(Wirelet... wirelets) {
        ContainerHandle<?> handle = link0().install(ContainerConfiguration::new, wirelets);
        return handle.configuration();
    }

    /** {@return a new container builder used for linking.} */
    private ContainerTemplate.Installer link0() {
        return NonRootContainerBuilder.of(ContainerTemplate.DEFAULT, BaseExtension.class, extension.container.application, extension.container);
    }

    void linkPrefix(Wirelet... wirelets) {
        throw new UnsupportedOperationException();
    }

    void linkPostfix(Wirelet... wirelets) {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns a special bean builder that can install beans for BaseExtension. Where BaseExtension is both the owner and
     * installer.
     *
     * @param template
     *            a template for the bean
     * @return a bean installer
     */
    private BeanTemplate.Installer newBeanBuilderSelf(BeanTemplate template) {
        return new PackedBeanInstaller(extension, extension, template);
    }

    /**
     * Creates a new BeanIntrospector for handling annotations managed by BeanExtension.
     *
     * @see Inject
     * @see OnInitialize
     * @see OnStart
     * @see OnStop
     */
    @Override
    protected BeanIntrospector newBeanIntrospector() {
        return new BeanIntrospector() {

            /** A template for bean lifecycle operations. */
            private static final OperationTemplate BEAN_LIFECYCLE_TEMPLATE = OperationTemplate.defaults().returnIgnore();

            private OperationHandle checkNotStaticBean(Class<? extends Annotation> annotationType, BeanMethod method) {
                if (beanKind() == BeanKind.STATIC) {
                    throw new ManagedBeanRequiredException(annotationType + " is not supported for static beans");
                }
                // Maybe lifecycle members cannot be static at all
                return method.newOperation(BEAN_LIFECYCLE_TEMPLATE);
            }

            /** Handles {@link Inject}. */
            @Override
            public void activatedByAnnotatedField(Annotation hook, BeanField field) {
                if (hook instanceof Inject) {
                    // checkNotStatic
                    // Det er jo inject service!???
                    // field.newBindableVariable().unwrap();
                    // OperationHandle handle = field.newSetOperation(null) .newOperation(temp);
                    // bean.lifecycle.addInitialize(handle, null);
                    throw new UnsupportedOperationException();
                } else if (hook instanceof Provide) {
                    Key<?> key = field.toKey();

                    if (!Modifier.isStatic(field.modifiers())) {
                        if (beanKind() != BeanKind.CONTAINER) {
                            throw new BuildException("Not okay)");
                        }
                    }

                    OperationSetup operation = OperationSetup.crack(field.newGetOperation(OperationTemplate.defaults()));
                    extension.container.sm.provide(key, operation, new FromOperationResult(operation));
                } else {
                    super.activatedByAnnotatedField(hook, field);
                }
            }

            /** Handles {@link Inject}, {@link OnInitialize}, {@link OnStart} and {@link OnStop}. */
            @Override
            public void triggeredByAnnotatedMethod(Annotation annotation, BeanMethod method) {
                BeanSetup bean = bean();

                if (annotation instanceof Inject) {
                    OperationHandle handle = checkNotStaticBean(Inject.class, method);
                    bean.operations.addLifecycleOperation(BeanLifecycleOrder.INJECT, handle);
                } else if (annotation instanceof OnInitialize oi) {
                    OperationHandle handle = checkNotStaticBean(OnInitialize.class, method);
                    bean.operations.addLifecycleOperation(BeanLifecycleOrder.fromInitialize(oi.order()), handle);
                } else if (annotation instanceof OnStart oi) {
                    OperationHandle handle = checkNotStaticBean(OnStart.class, method);
                    bean.operations.addLifecycleOperation(BeanLifecycleOrder.fromStarting(oi.order()), handle);
                } else if (annotation instanceof OnStop oi) {
                    OperationHandle handle = checkNotStaticBean(OnStop.class, method);
                    bean.operations.addLifecycleOperation(BeanLifecycleOrder.fromStopping(oi.order()), handle);
                } else if (annotation instanceof Provide) {
                    OperationTemplate temp2 = OperationTemplate.defaults().returnType(method.operationType().returnRawType());
                    if (!Modifier.isStatic(method.modifiers())) {
                        if (beanKind() != BeanKind.CONTAINER) {
                            throw new BeanInstallationException("Not okay)");
                        }
                    }
                    OperationSetup operation = OperationSetup.crack(method.newOperation(temp2));
                    bean.container.sm.provide(method.toKey(), operation, new FromOperationResult(operation));
                } else if (annotation instanceof Export) {
                    OperationTemplate temp2 = OperationTemplate.defaults().returnType(method.operationType().returnRawType());

                    if (!Modifier.isStatic(method.modifiers())) {
                        if (beanKind() != BeanKind.CONTAINER) {
                            throw new BeanInstallationException("Not okay)");
                        }
                    }
                    OperationSetup operation = OperationSetup.crack(method.newOperation(temp2));
                    bean.container.sm.export(method.toKey(), operation);
                } else if (annotation instanceof Main) {
                    if (!isInApplicationLifetime()) {
                        throw new BeanInstallationException("Must be in the application lifetime to use @" + Main.class.getSimpleName());
                    }

                    bean.container.lifetime.entryPoints.takeOver(BaseExtension.this, BaseExtension.class);

                    bean.container.lifetime.entryPoints.entryPoint = new OldEntryPointSetup();

                    OperationTemplate temp = OperationTemplate.defaults().returnType(method.operationType().returnRawType());
                    OperationHandle os = method.newOperation(temp);
                    // os.specializeMirror(() -> new EntryPointMirror(index));

                    MainThreadOfControl mc = bean.container.lifetime.entryPoints.entryPoint.mainThread();

//                    os.generateMethodHandleOnCodegen(mh -> mc.generatedMethodHandle = mh); Same dont know what is prettiest
                    runOnCodegen(() -> mc.generatedMethodHandle = os.generateMethodHandle());
                } else {
                    super.triggeredByAnnotatedMethod(annotation, method);
                }
            }

            /** Handles {@link ContainerGuest}, {@link InvocationArgument} and {@link CodeGenerated}. */
            @Override
            public void activatedByAnnotatedVariable(Annotation annotation, BindableVariable v) {
                if (annotation instanceof GuestIntoAdaptor) {
                    Variable va = v.variable();
                    if (va.rawType().equals(ApplicationMirror.class)) { // AssignableTo in case of
                        // TODO we need to be able to insert some casts here ApplicationMirror -> to actual type
                        v.bindOp(new Op1<ApplicationLaunchContext, ApplicationMirror>(a -> a.mirror()) {});
                    } else if (va.rawType().equals(String.class)) {
                        // Burde vel vaere en generics BeanInvocationContext her???
                        v.bindOp(new Op1<ApplicationLaunchContext, String>(a -> a.name()) {});
                    } else if (va.rawType().equals(LifecycleController.class)) {
                        v.bindOp(new Op1<ApplicationLaunchContext, LifecycleController>(a -> a.runner.runtime) {});
                    } else if (va.rawType().equals(ServiceLocator.class)) {
                        v.bindOp(new Op1<ApplicationLaunchContext, ServiceLocator>(a -> a.serviceLocator()) {});
                    } else {
                        throw new UnsupportedOperationException("Unknown Container Guest Service " + va.rawType());
                    }
                } else if (annotation instanceof ComputedConstant cg) {
                    if (beanAuthor().isApplication()) {
                        throw new BeanInstallationException(
                                "@" + ComputedConstant.class.getSimpleName() + " can only be used by extensions, annotation = " + cg);
                    }
                    // Create the key
                    Key<?> key = v.toKey();

                    // We currently only allow code generated services to be injected in one place
                    BindableVariable bv = BeanSetup.CODEGEN.get(this).putIfAbsent(key, v);
                    if (bv != null) {
                        failWith(key + " Can only be injected once for bean ");
                    }
                    varsToResolve.add(v);
                } else {
                    super.activatedByAnnotatedVariable(annotation, v);
                }
            }

            @Override
            public void activatedByVariableType(Class<?> hook, Class<?> actualHook, UnwrappedBindableVariable binding) {
                OperationSetup operation = ((PackedBindableWrappedVariable) binding).v.operation;

                if (ApplicationLaunchContext.class.isAssignableFrom(hook)) {
                    binding.bindContext(ApplicationLaunchContext.class);
                } else if (hook == ExtensionContext.class) {
                    if (beanAuthor().isApplication()) {
                        binding.failWith(hook.getSimpleName() + " can only be injected into extensions");
                    }
//                    if (binding.availableInvocationArguments().isEmpty() || binding.availableInvocationArguments().get(0) != ExtensionContext.class) {
//                        // throw new Error(v.availableInvocationArguments().toString());
//                    }
                    binding.bindContext(ExtensionContext.class);
                } else if (actualHook == DeploymentMirror.class) {
                    binding.bindConstant(operation.bean.container.application.deployment.mirror());
                } else if (actualHook == ApplicationMirror.class) {
                    binding.bindConstant(operation.bean.container.application.mirror());
                } else if (actualHook == ContainerMirror.class) {
                    binding.bindConstant(operation.bean.container.mirror());
                } else if (actualHook == AssemblyMirror.class) {
                    binding.bindConstant(operation.bean.container.assembly.mirror());
                } else if (actualHook == BeanMirror.class) {
                    binding.bindConstant(operation.bean.mirror());
                } else if (actualHook == OperationMirror.class) {
                    binding.bindConstant(operation.mirror());
                } else {
                    // will always fail
                    binding.checkAssignableTo(ExtensionContext.class, DeploymentMirror.class, ApplicationMirror.class, ContainerMirror.class,
                            AssemblyMirror.class, BeanMirror.class, OperationMirror.class);
                }
            }
        };
    }

    /** {@return a mirror for this extension.} */
    @Override
    protected BaseExtensionMirror newExtensionMirror() {
        return new BaseExtensionMirror(extension.container);
    }

    /** {@inheritDoc} */
    @Override
    protected BaseExtensionPoint newExtensionPoint() {
        return new BaseExtensionPoint();
    }

    /**
     * {@inheritDoc}
     * <p>
     * BaseExtension is always the last extension to be closed. As it is the only extension that has
     * {@link internal.app.packed.container.ExtensionModel#orderingDepth()} 0.
     */
    @Override
    protected void onAssemblyClose() {
        // close child extensions first
        super.onAssemblyClose();

        for (BindableVariable v : varsToResolve) {
//            Supplier<?> sup = codegens.get(v.toKey());
//            if (sup == null) {
//                throw new InternalExtensionException(v.toKey() + " not bound for bean ");
//            }
//            v.bindComputedConstant(sup);

            if (!v.isBound()) {
                throw new InternalExtensionException(v.toKey() + " not bound for bean ");
            }
        }

        // A lifetime root lets order some dependencies
        if (isLifetimeRoot()) {
            extension.container.lifetime.orderDependencies();
        }
    }

    // requires bliver automatisk anchoret...
    // anchorAllChildExports-> requireAllChildExports();
    public void requires(Class<?>... keys) {
        requires(Key.ofAll(keys));
    }

    /**
     * Explicitly adds the specified key to the list of required services. There are typically two situations in where
     * explicitly adding required services can be useful:
     * <p>
     * First, services that are cannot be specified at build time. But is needed later... Is mainly useful when we the
     * services to. For example, importAll() that injector might not a service itself. But other that make use of the
     * injector might.
     *
     *
     * <p>
     * Second, for manual service requirement, although it is often preferable to use contracts here
     * <p>
     * In any but the simplest of cases, contracts are useful
     *
     * @param keys
     *            the key(s) to add
     */
    public void requires(Key<?>... keys) {
        requireNonNull(keys, "keys is null");
        checkIsConfigurable();
        throw new UnsupportedOperationException();
    }

    // Think we need installPrototype (Which will fail if not provided or exported)
    // providePrototype would then be installPrototype().provide() // not ideal
    // Men taenker vi internt typisk arbejde op i mod implementering. Dog ikke altid
    // providePerRequest <-- every time the service is requested
    // Also these beans, can typically just be composites??? Nah

    public void requiresOptionally(Class<?>... keys) {
        requiresOptionally(Key.ofAll(keys));
    }

    /**
     * Adds the specified key to the list of optional services.
     * <p>
     * If a key is added optionally and the same key is later added as a normal (mandatory) requirement either explicitly
     * via # {@link #serviceRequire(Key...)} or implicitly via, for example, a constructor dependency. The key will be
     * removed from the list of optional services and only be listed as a required key.
     *
     * @param keys
     *            the key(s) to add
     */
    // How does this work with child services...
    // They will be consumed
    public void requiresOptionally(Key<?>... keys) {
        requireNonNull(keys, "keys is null");
        checkIsConfigurable();
        throw new UnsupportedOperationException();
    }

    public ServiceNamespaceConfiguration newServiceNamespace(Object configuration) {
        return serviceNamespace("main");
    }

    public ServiceNamespaceConfiguration serviceNamespace() {
        return serviceNamespace("main");
    }

    public ServiceNamespaceConfiguration serviceNamespace(String name) {
        // Will automatically create one with default settings
        throw new UnsupportedOperationException();
    }

    // transformAllBeans() <-- includes extension beans... (Must be open)
    public Runnable transformAllBeans(Consumer<? super BeanClassMutator> transformer) {
        throw new UnsupportedOperationException();
    }

    // All beans that are installed with the assembly
    /**
     * <p>
     * If there are multiple all bean transformers active at the same type. They will be invoked in the order they where
     * registered. The first one registered will be run first
     *
     * @param transformer
     * @return A runnable that be can run after which the transformer will no longer be applied when installing beans.
     */
    // Also a version with BeanClass?? , Class<?>... beanClasses (
    public Runnable transformBeans(Consumer<? super BeanClassMutator> transformer) {
        throw new UnsupportedOperationException();
    }

    /**
     * All beans. the consumer is invoked once on every bean that is installed with
     * <p>
     * If there are any all bean transformers. They will be invoked before this
     *
     * @param transformer
     *            the bean transformer
     */
    // Det maa sgu blive en extra metode
    // BeanInstaller.forceOpBind("XOp", 2, "FooBar");

    public void transformNextBean(Consumer<? super BeanClassMutator> transformer) {}

    static class FromLinks {
        boolean exportServices;
    }
}

/**
 * An extension that deals with the service functionality of a container.
 * <p>
 * This extension provides the following functionality:
 *
 * is extension provides functionality for exposing and consuming services.
 *
 *
 */
//Functionality for
//* Explicitly requiring services: require, requiOpt & Manual Requirements Management
//* Exporting services: export, exportAll

//// Was
// Functionality for
// * Explicitly requiring services: require, requiOpt & Manual Requirements Management
// * Exporting services: export, exportAll
// * Providing components or injectors (provideAll)
// * Manual Injection

// Har ikke behov for delete fra ServiceLocator

// Future potential functionality
/// Contracts
/// Security for public injector.... Maaske skal man explicit lave en public injector???
/// Transient requirements Management (automatic require unresolved services from children)
/// Integration pits
// MHT til Manuel Requirements Management
// (Hmm, lugter vi noget profile?? Nahh, folk maa extende BaseAssembly og vaelge det..
// Hmm saa auto instantiere vi jo injector extensionen
//// Det man gerne vil kunne sige er at hvis InjectorExtensionen er aktiveret. Saa skal man
// altid bruge Manual Requirements
// contracts bliver installeret direkte paa ContainerConfiguration

// Profile virker ikke her. Fordi det er ikke noget man dynamisk vil switche on an off..
// Maybe have an Container.onExtensionActivation(Extension e) <- man kan overskrive....
// Eller @ContainerStuff(onActivation = FooActivator.class) -> ForActivator extends ContainerController

// Taenker den kun bliver aktiveret hvis vi har en factory med mindste 1 unresolved dependency....
// D.v.s. install(Class c) -> aktivere denne extension, hvis der er unresolved dependencies...
// Ellers selvfoelgelig hvis man bruger provide/@Provides\
//final void embed(Assembly assembly) {
///// MHT til hooks. Saa tror jeg faktisk at man tager de bean hooks
//// der er paa den assembly der definere dem
//
//// Men der er helt klart noget arbejde der
//throw new UnsupportedOperationException();
//}

class ZServiceSandbox {

    public void applicationLink(Assembly assembly, Wirelet... wirelets) {
        // Syntes den er maerkelig hvis vi havde ApplicationWirelet.NEW_APPLICATION
        // Den her er klarere
        // linkNewContainerBuilder().build(assembly, wirelets);
    }

    // Validates the outward facing contract
    public void checkContract(Consumer<? super ServiceContract> validator) {}

    // Det der er ved validator ServiceContractChecker er at man kan faa lidt mere context med
    // checkContract(Service(c->c.checkExact(sc));// ContractChecker.exact(sc));
    public void checkContractExact(ServiceContract sc) {}

    public void exportsTransform(Consumer<? super ServiceOutgoingTransformer> s) {

    }

    public void provideAll(ServiceLocator locator, Consumer<Object> transformer) {
        // ST.contract throws UOE
    }

    public void resolveFirst(Key<?> key) {}

    /**
     * Performs a final transformation of any exported service.
     *
     * This method can perform any final adjustments of services before they are made available to any parent container.
     * <p>
     * The transformation takes place xxxx
     *
     * @param transformer
     *            transforms the exported services
     */
}