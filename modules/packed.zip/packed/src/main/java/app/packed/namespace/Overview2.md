----
Namespace Scope/Extend  -> A tree of containers
Namespace Active -> A partial tree of above containers where the namespace is used

Permissions control whether or not some nodes in the tree can be active 

ContainerPropagation, controls namespace extend