Taenkt som et "modsvar" til app.packed.build

Maaske flyt meget af Lifetime her