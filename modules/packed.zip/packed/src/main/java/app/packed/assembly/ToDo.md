
* Rename BuildableAssembly to something better. To similar to BaseAssembly
