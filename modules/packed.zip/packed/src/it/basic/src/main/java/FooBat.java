
public class FooBat {

}
